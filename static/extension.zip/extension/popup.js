const form = document.getElementById('control-row');
const go = document.getElementById('go');
const input = document.getElementById('input');
const message = document.getElementById('message');

// The async IIFE is necessary because Chrome <89 does not support top level await.
(async function initPopupWindow() {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.storage.local.get(["username"]).then((result) => {
    input.value = result.username
  });

  input.focus();
})();

form.addEventListener('submit', handleFormSubmit);

async function handleFormSubmit(event) {
  event.preventDefault();
  clearMessage();
  let username = input.value.trim();
  chrome.storage.local.set({ "username": username }).then(() => {
    console.log("Value is set to " + username);
    setMessage("saved successfully!");
  });
}

function setMessage(str) {
  message.textContent = str;
  message.hidden = false;
}

function clearMessage() {
  message.hidden = true;
  message.textContent = '';
}